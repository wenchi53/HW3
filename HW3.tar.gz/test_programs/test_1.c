int main(){
  int numbers[2];
  int i; 
  for(i = 4; i>=0; i--){
    numbers[i] = i;
  }
  return 0;
}
