int main(){
  int numbers[3];
  int i; 
  for(i = 0; i<4; i++){
    numbers[i] = i;
  }
  return 0;
}
