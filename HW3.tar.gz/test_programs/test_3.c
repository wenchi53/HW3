int main(){
  int numbers[3];
  numbers[-1] = 5;
  return 0;
}
