int main(){
  int numbers[3];
  int i; 
  for(i = 0; i<4; i++){
    numbers[i] =1;
    numbers[i+1]=2;
  }
  return 0;
}
