#!/bin/bash

test_dir="./test_programs"

rm -f *.so *.os *.bc
rm -f $test_dir/*.bc
